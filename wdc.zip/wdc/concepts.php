<?php

	include("sources.php");


	/* Get arguments from line commnad */

	$entity_proc=$argv[1];


	$url = "https://www.wikidata.org/w/api.php?action=sitematrix&format=php&utf8="; 
	$a = unserialize(file_get_contents($url));

	$num_db=$a["sitematrix"]["count"];

	foreach ($a["sitematrix"] as $name=>$record) {

		if ($name<>"count" and $name<>"specials") {
			foreach ($record["site"] as $sitelink) {
				$site[$sitelink["dbname"]]=$sitelink["url"];
			}
		}

		if ($name==="specials") {
			foreach ($record as $sitelink) {
				$site[$sitelink["dbname"]]=$sitelink["url"];
			}
		}

	}




	/* Open files */

	$fp = fopen('data/'.$entity_proc.'.ttl', 'w');

	fwrite($fp, "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .\n");
	fwrite($fp, "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .\n");
	fwrite($fp, "@prefix skos: <http://www.w3.org/2004/02/skos/core#> .\n");
	fwrite($fp, "@prefix wd: <http://www.wikidata.org/entity/> .\n");
	fwrite($fp, "@prefix wdt: <http://www.wikidata.org/prop/direct/> .\n");
	fwrite($fp,"\n");
	fwrite($fp,"<http://www.wikidata.org/categories> rdf:type skos:ConceptScheme ;\n");
	fwrite($fp,"    skos:prefLabel \"Wikidata categories\"@en .\n\n");



	// echo $list_entities."\n";

	$url = "https://www.wikidata.org/w/api.php?action=wbgetentities&ids=".$entity_proc."&props=labels|aliases|sitelinks&format=php&utf8="; 
	$a = unserialize(file_get_contents($url));

	foreach ($a["entities"] as $entity=>$data_entity) {

		fwrite($fp,"wd:".$entity." rdf:type skos:Concept ;\n");
		fwrite($fp,"    skos:inScheme <http://www.wikidata.org/categories> ");


		if (isset($data_entity["labels"])) {
			foreach ($data_entity["labels"] as $label) {
				fwrite($fp,";\n    skos:prefLabel \"".$label["value"]."\"@".$label["language"]." ");
			}
		}

		if (isset($data_entity["aliases"])) {
			foreach ($data_entity["aliases"] as $item) {
				foreach ($item as $label) {
					fwrite($fp,";\n    skos:altLabel> \"".$label["value"]."\"@".$label["language"]." ");
				}
			}
		}


		foreach ($data_entity["sitelinks"] as $item) {

	
			if (in_array($item["site"],$array_sources)) {



				/* GET BROADER CATEGORIES */

				$repeat_query=true;
				$cmcontinue="";
				while ($repeat_query==true) {	
					$repeat_query = false;

					$url_wiki = $site[$item["site"]]."/w/api.php?action=query&generator=categories&titles=".urlencode($item["title"])."&prop=pageprops|categoryinfo&format=php&utf8=".$cmcontinue;
					$b = unserialize(file_get_contents($url_wiki));

					if (isset($b["continue"]["cmcontinue"])) {
						$repeat_query = true;
						$cmcontinue = $b["continue"]["cmcontinue"];
					}

					if (isset($b["query"]["pages"])) {
						foreach ($b["query"]["pages"] as $broadcat) {
							if (isset($broadcat["pageprops"]["wikibase_item"])) {
								if (!isset($broader[$broadcat["pageprops"]["wikibase_item"]])) {$broader[$broadcat["pageprops"]["wikibase_item"]]=$broadcat["title"];}
								// fwrite($fp,"<http://www.wikidata.org/entity/".$entity_proc."> <http://www.w3.org/2004/02/skos/core#broader> <http://www.wikidata.org/entity/".$broadcat["pageprops"]["wikibase_item"]."> <http://www.wikidata.org/categories/".$item["site"]."> .\n");
							}
						}
					}
				}


				/* GET NARROWER CATEGORIES */

				$repeat_query=true;
				$cmcontinue="";
				while ($repeat_query==true) {	
					$repeat_query = false;

					$url_wiki = $site[$item["site"]]."/w/api.php?action=query&generator=categorymembers&gcmtitle=".urlencode($item["title"])."&gcmtype=subcat&prop=pageprops|categoryinfo&format=php&utf8=".$cmcontinue;
					$b = unserialize(file_get_contents($url_wiki));

					if (isset($b["continue"]["cmcontinue"])) {
						$repeat_query = true;
						$cmcontinue = $b["continue"]["cmcontinue"];
					}

					if (isset($b["query"]["pages"])) {
						foreach ($b["query"]["pages"] as $narrowcat) {
							if (isset($narrowcat["pageprops"]["wikibase_item"])) {
								if (!isset($narrower[$narrowcat["pageprops"]["wikibase_item"]]) or $item["site"]=="enwiki") {$narrower[$narrowcat["pageprops"]["wikibase_item"]]=$narrowcat["title"];}
								// fwrite($fp,"<http://www.wikidata.org/entity/".$entity_proc."> <http://www.w3.org/2004/02/skos/core#narrower> <http://www.wikidata.org/entity/".$narrowcat["pageprops"]["wikibase_item"]."> <http://www.wikidata.org/categories/".$item["site"]."> .\n");
							}
						}
					}
				}

			}


		}

	}
	

	$prevalue="";
	foreach ($broader as $target=>$value) {
		fwrite($fp,";".$prevalue."\n    skos:broader wd:".$target);
		$prevalue=" # ".$value;
	}
	if ($prevalue!=="") {fwrite($fp,$prevalue);}
	$prevalue="";
	foreach ($narrower as $target=>$value) {
		fwrite($fp,";".$prevalue."\n    skos:narrower wd:".$target);
		$prevalue=" # ".$value;
	}
	if ($prevalue!=="") {fwrite($fp,$prevalue);}
	fwrite($fp,".\n\n");


	fclose($fp);

?>
