<?php

	$array_sources=array("enwiki","dewiki","frwiki","eswiki","simplewiki","nlwiki","viwiki","itwiki","ruwiki","zhwiki","ptwiki","jawiki","plwiki");

?>
